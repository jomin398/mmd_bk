画架包含UV表情show，可以切换显示图像
显示图像可以通过修改 tex2/paint.png 右半侧的图像来更换

--
从神帝宇模型包里额外增加 骑士，骑士刀，画架，画笔2

------------------------------------------------
# blender 工程注意
Griseo v3.9.6b.blend 为原始0.1倍率，可直接用于blender工程
导入动作时需要设定缩放倍率为 0.1
导出mmd模型时需要设定缩放倍率到10

pre_mat_1 Griseo nuke v3.10.10b.blend 包含预先设定好的渲染材质

# mmd 工程注意
模型太小了，除了原始大小的模型，增加一个缩放为 1.3 倍模型，可以直接使用多数动作。
Griseo v3.9.6b x1.0.pmx 原始1.0大小，高度约为1.5m
Griseo v3.9.6b x1.3.pmx 缩放1.3倍后大小，高度约为2m

没有 x1.0 和 x1.3 标注的，均为 x1.0 倍率
东西太多了，如果需要x1.3倍率的道具或骑士，请自行使用blender或pmxedit进行缩放。

------------------------------------------------
模型改造者 NameLess(NL)
改造自
那时符华染流年提取的格蕾修模型
MDJSN改造的芭芭拉的胸部
MDJSN的Vag_Mark_3
神帝宇制作的格蕾修模型脸部表情
非常感谢他们

进行了如下改造
拼接，素体生成，部分布线改造，新增和重制表情，刚体改进

允许编辑改造和二次配布
请在合法的范围内使用

请不要用于商业用途
请不要在不适宜的地方使用

那时符华染流年，格蕾修 https://www.aplaybox.com/details/model/JKp7A2hoOtbc
MDJSN，芭芭拉 https://mmda.booru.org/index.php?page=post&s=view&id=2562
MDJSN，Vag_Mark_3 https://mmda.booru.org/index.php?page=post&s=view&id=2833
神帝宇，格蕾修 https://www.bilibili.com/video/BV1ut4y1x7vi
米哈游，崩坏3 https://www.bh3.com
