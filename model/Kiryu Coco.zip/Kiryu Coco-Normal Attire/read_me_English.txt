
===========================
MMD model data

桐生ココ　ver1.0

制作者/Modeller：縞々
===========================


This is a fan art model of Kiryu Coco, a Vtuber belonging to Hololive.



Terms of Use
===========================
The following terms of use apply to the "Kiryu Coco MikuMikuDance Model Data" (hereinafter referred to as the "Model Data").

If you are unable to read the terms of use or do not agree to the terms of use, you may not use this model data at all.

Please use the model data at your own risk. I will not be held responsible for any kind of trouble.

If anyone violates the terms of this agreement, or if "Cover Co., Ltd." requests that distribution be stopped, distribution may be stopped without notice, and all use of this data may be prohibited.

This model data may be upgraded without notice, and the terms and conditions may be changed without notice.

Please always use the data in accordance with the online terms of use, which are up-to-date.
Prohibited items that are not listed in these terms and conditions may be listed here, so please check them.
(https://ch.nicovideo.jp/MMDshimaneko/blomaga/ar1737131)


Please be sure to follow the "Hololive Derivative Works License Agreement".
(https://www.hololive.tv/terms)



*NOT ALLOWED*
=================================================
Use in a manner that could be misconstrued as official Cover Corporation, Hololive, or Kiryu Coco, or use in a manner that could cause trouble.

Do not use the site for activities or purposes that are offensive to public order and morals, or for political or religious propaganda.

Use in works that depict R-18, include obscene,  or sex.

Use in works that grotesque,  contain excessive depictions of violence.

Posting of videos or still images on sites other than YouTube, Nico Nico Douga, and Twitter (posting on Reddit is prohibited) .

Commercial use and exchange involving money.

Output to a three-dimensional form using a 3D printer, etc.

Dressing the model in a costume that exposes more than 50% of the skin (including nude, semi-nude, and swimsuit).

Modification of model data (not including what is stated in the Allowed).

Use of part of this model data to modify or create other characters, and diversion of costumes.	

Modification of this model data to other characters.

Use of still images using this model data as icons for social networking services (except for still images posted by the creator on Twitter, etc.).

Posting videos or still images with the camera intentionally peeking inside the skirt, or with the arm clearly penetrating the chest.

Redistribution, exchange, or transfer of model data (modified or unmodified)

Uploading model data to applications, websites, etc. that may lead to redistribution.

Using models other than MMD and MMM (use in VRchat is prohibited).

Falsely claiming that the creator of this data.

Leaking passwords or hints.


*ALLOWED*
=================================================

Changing or adding physics operations

Changes in weight values.

Add expression morphs and bones.

Changing the color of textures and spheres (rewriting is prohibited)

Change the color of textures and spheres (Rewriting is not allowed.) 

Change clothes (Read the terms of use of the model you want to change, and only if it is possible. If you do, please make sure to adjust the body shape, skin texture color, etc. (But also, altering outfits to make them more revealing is prohibited.


　Other things to be aware of
===========================
There are some parts that are not well weighted and some parts that are not well calculated.
The model has very large breasts, so please be careful not to pierce the arms.
The breasts do not sway much, but that is a specification.

===========================

When using this model data, please include the model creator's name "縞々(shimashima)".

If you see anyone other than "縞々(shimashima)" distributing this model data , please tell them to stop distributing it.

If you see a work that violates the terms of this model data, please ask the person to remove the work.

Thank you for your cooperation.

===========================
MikuMikuDance Model created by：縞々(shimashima)
Contact：Twitter　＠SmOc_O


Thank you for reading this far.
The password for unzipping the file is at the end of "read_me_Japanese.tex".

By using the password to decompress the model data, you agree to the terms of this agreement.




Translated with www.DeepL.com/Translator (free version)