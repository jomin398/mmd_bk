3D model PMX for MMD
Fubuki Bunny 0.7

It is a fan-made model of Vtuber Fubuki.

Adhesive plasters and nipless related morphs are in the eyebrow morphs.




We hope that you will use it in accordance with the following terms of use and Hololive's derivative work guidelines.
* Please give priority to Hololive's derivative work guidelines.

Hololive Derivative Work Guidelines
https://www.hololive.tv/terms


【terms of use】

･ In case of R18 content Search exclusion, no official tag
　(It is OK if the content is for the general public.)

･ Redistribution is not permitted (included in the game etc. as it is)
･ Permission for commercial use
･ Permission for modification
･ Permission to distribute derivative works
･ Permission to divert data at the time of distribution and sale (Please refrain from distributing 3D model data in a form that can be used as it is in games etc.)
･ Permitting expressions for adults (sexual and violent expressions)
･ Permission to use after converting to other formats (fbx, vrm, etc.)
･ Please write the copyright as much as possible.
･ Please use at your own risk, considering the place of use.

---------------------------------------------------------------------------

Model production: Tarara Tarako
© Tarara Tarako 2022
Email: tarara.tarako.tarara@gmail.com
Fantia: https://fantia.jp/fanclubs/104882
Twitter: https://twitter.com/TararaTarako1
We would be grateful if you could give us feedback on your opinions and impressions after using it.

Production software: Blender 2.93.1
Made with Blender add-on mmd tools.

---------------------------------------------------------------------------

Change log

 2023/10/6
 0.7 distribution started
