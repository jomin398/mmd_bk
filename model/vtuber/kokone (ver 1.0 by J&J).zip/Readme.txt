If you do not fully understand the original terms of use written in Japanese, do not edit, redistribute and/or trade this model.
There are additional conditions in the original text.

●れんくう式kokone（心響）猫ランジェリー黒

◇モデルについて
kokone（心響）のMikuMikuDance（樋口M様）用モデルデータです。
あっきー人様のキャラクターデザインに基づいてモデリングさせて頂いております。

◇使い方
ヘッドフォンの発光部は、AutoLuminous Ver.4.2（そぼろ様）に対応確認済みです。

◇改造再配布について
当モデルデータをそのままの配布はご遠慮ください。
改造再配布する場合は、名称及び本規約を継承し本テキストを添付してください。
株式会社インターネット様のキャラクター使用に関するガイドラインに沿って再配布してください。
http://www.ssw.co.jp/products/vocal/character_guideline/index.html

◇免責事項
当モデルデータを使用して発生した何らかのトラブルにおいて、当方は一切の責任を負いません。

◇商用利用について
商用利用に関しましては、株式会社インターネット様のガイドラインに準じます。
http://www.ssw.co.jp/products/vocal/character_guideline/index.html

◇禁止事項
公序良俗に反する利用。
版権元様、各関係者様にご迷惑となる利用。
アダルトコンテンツへの利用。
当モデルデータをそのまま再配布。

◇キャラクター使用に関するガイドライン
kokone（心響）は株式会社インターネット様の製品です。
株式会社インターネット様のガイドラインに沿ってご利用ください。
http://www.ssw.co.jp/products/vocal/character_guideline/index.html

◇使用ツール
PMXエディター：極北P様

関係者の方々及びご利用いただく方々に心よりお礼申し上げます。

◇当モデル作者
モデリング＆セットアップ：レンにゃ＆くうわんこ
mylist：http://www.nicovideo.jp/mylist/35741889
twitter：kuu_wanko

◇更新履歴
2016.02.05　ゴミ（涙の残骸）削除しました。
