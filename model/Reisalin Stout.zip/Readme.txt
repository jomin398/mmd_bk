Thank you for downloading


Assets where ripped from the Switch verson of Atelier Ryza (JPN). Ripped was thanks to Ploaj's tool, however edited quite a bit by me (Kuro).

Standard edits include merging meshes together to make a whole (like two halves of a face) and other slight changes caused by messy exports.


If there is anything you "Need" To know, it would be listed below:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

I combined the "Wet" textures with the regular model, importing over the WetDrops, which was the only percieved difference in the shape of said model.
The clothing doesn't stick more, the textures mearly turn more darker and saturated as if infused with water.

But if you think there really is a difference, please let me know.