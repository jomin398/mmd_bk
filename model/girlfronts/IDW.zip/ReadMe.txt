IDW Assistant (custom) outfit by Marrsys.

Model parts used from the Senran Kagura games, Mostly Peach Beach Splash.
Face model originally from CrossMMD's Yumi port, edited for IDW's model by Marrsys.

Feel free to edit the model/textures, port to other games/programs, etc.

IDW from Girls' Frontline by Mica Team.
Credit for the original model meshes go to Tamsoft and Marvelous.

Crediting me is not necessary, but is much appreciated.

Enjoy.